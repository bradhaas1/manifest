/**
 *
 * %%Title%% :: Page-Specific Functionality
 *
 *  Dependencies:
 *   Zepto1.0
 */


// if needed, do something device switches to landscape orientation
function landscapeHandler(){

}


// if needed, do something device switches to portrait orientation
function portraitHandler(){

}


/**
 * Called when all components have been successfully loaded on page (required)
 */
function loadCompleteHandler() {
	// set up custom orientation handlers
	$klcd.initOrientation(landscapeHandler, portraitHandler);

   // SET BACKGROUNDS
   // By default, dummy jpegs for each device are exported for you.
   // These should be replaced by a project-specific background
   // (can alter to PNGs if necessary)
   //
   // If you don't have a graphical background, you can specify a color:
   //   $klcd.setLandscapeBg({'backgroundColor' : '#ffcc00'});
   //   $klcd.setLandscapeBg({'backgroundColor' : 'white'});

	// set landscape background
	$klcd.setLandscapeBg({'src' : 'images/informational/bg_ls.jpg'});

	// set portrait background
	$klcd.setPortraitBg({ 'src': 'images/informational/bg_pt.jpg' });

   // display in emulator (for testing)
   if ($klcdEmulate) $klcdEmulate.displayConsole();

   // WRITE CUSTOM JS HERE...
   // ...
   // ...
   // ...

}


/**
 * Called when the background image has completed downloading (required)
 */
function backgroundPreloadComplete() {
	// reveal content after a few milliseconds
	__booty.liftVeil();
}
